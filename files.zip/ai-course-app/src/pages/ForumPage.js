import React from 'react';

const ForumPage = () => {
  return (
    <div>
      <h1>Forum</h1>
    </div>
  );
};

export default ForumPage;