import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to the AI Course Platform</h1>
    </div>
  );
};

export default HomePage;