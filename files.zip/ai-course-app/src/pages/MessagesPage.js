import React from 'react';

const MessagesPage = () => {
  return (
    <div>
      <h1>Messages</h1>
    </div>
  );
};

export default MessagesPage;