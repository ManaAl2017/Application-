import React from 'react';

const CoursesPage = () => {
  return (
    <div>
      <h1>Courses</h1>
    </div>
  );
};

export default CoursesPage;